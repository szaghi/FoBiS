"""FoBiS.py main package"""
