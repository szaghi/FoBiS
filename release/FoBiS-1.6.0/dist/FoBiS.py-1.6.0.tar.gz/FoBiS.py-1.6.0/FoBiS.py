#!/usr/bin/env python
"""Wrapper of FoBiS.py program extracted from fobis package"""
from fobis.fobis import main
if __name__ == '__main__':
  main()
